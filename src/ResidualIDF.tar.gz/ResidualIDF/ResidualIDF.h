/*
 * ResidualIDF.h
 *
 *  Created on: 14-Dec-2013
 *      Author: cfilt
 */

#ifndef RESIDUALIDF_H_
#define RESIDUALIDF_H_
#include <map>
#include <string>
#include <fstream>
#include <math.h>
#include "WikiReader.h"
#include "boost/filesystem/operations.hpp"
#include "boost/algorithm/string/split.hpp"
#include "boost/algorithm/string/trim.hpp"
#include"InfoIDF.h"
using namespace std;
class ResidualIDF{
private:
	map<string,double> wordMap;
	map<string,InfoIDF> wordVals;
	int totalDocs;
public:
	ResidualIDF(){
		totalDocs=0;
	}
	void calculateInfo(string dir);
	void calculateInfoWiki(const char* wikiPath);
	void printSortedIDFs(ofstream& out);
};
#endif /* RESIDUALIDF_H_ */
