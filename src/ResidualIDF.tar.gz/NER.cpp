/*
 * NER.cpp
 *
 *  Created on: 15-Dec-2013
 *      Author: Rahul Sharnagat
 *
 */
#include "ResidualIDF/ResidualIDF.h"
int main() {

	ResidualIDF s;
	ofstream out;
	out.open("sortedOuput.txt", ios::out);
	s.calculateInfoWiki("/home/cfilt/wikiDump/hindi/hindi.txt");
	s.printSortedIDFs(out);
	out.close();
	return 0;

}

